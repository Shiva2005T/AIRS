# mock_analysis.py
import json
import os
import subprocess

def mock_detect_anomaly(log):
    # Match more realistic threats
    keywords = ["anomaly", "error", "unauthorized", "sql injection", "malware", "suspicious", "failed login"]
    return any(word in log.lower() for word in keywords)

def read_logs():
    print("\n Running Mock Analysis...\n")
    if not os.path.exists("received_logs.jsonl"):
        print("[!] Log file not found yet. Try again after logs are received.")
        return None
    with open("received_logs.jsonl", "r") as f:
        for line in f:
            data = json.loads(line)
            log_msg = data.get("log", "") or data.get("message", "")
            if mock_detect_anomaly(log_msg):
                print(f"[ ALERT] Anomaly detected in: {log_msg}")
                return {"rule_id": "R001", "log": log_msg}
    return None

if __name__ == "__main__":
    result = read_logs()
    if result:
        with open("detected_anomaly.json", "w") as f:
            json.dump(result, f)
        print("[✓] Anomaly passed to playbook resolver.")
        
        # Automatically invoke GPT and action
        subprocess.call(["python", "mock_gpt.py"])
        subprocess.call(["python", "mock_action.py"])
    else:
        print("[✓] No anomalies found.")
